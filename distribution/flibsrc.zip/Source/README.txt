FLIB
----

This code needs TI-GCC to be compiled (tigcc.ticalc.org).

You can change the target calculator by changing the "#define _89" to "#define _92".


If you change the source code, please respect the indentation conventions:
indent -bap -bbb -nsob -bl -bli0 -cli4 -cbi0 -ss -npcs -ncs -saf -sai -saw -di16 -nbc -psl -bls -i4 -ci4 -lp -ts4 -l140 -bbo -hnl source_name
Attention, the indent program has some problems with the GNU cast constructors like &(SCR_RECT){{x1,y1,x2,y2}}.
